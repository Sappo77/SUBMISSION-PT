export default {
  plugins: {
    tailwindcss: {},  // <--- Pastikan TULISANNYA HANYA 'tailwindcss' (tanpa @ dan tanpa /postcss)
    autoprefixer: {},
  },
}
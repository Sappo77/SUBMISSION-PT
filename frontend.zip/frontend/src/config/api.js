// Konfigurasi API untuk koneksi ke backend
const API_CONFIG = {
  // Ganti dengan IP address laptop yang menjalankan backend
  BASE_URL: 'http://192.168.1.100:8080', // Contoh IP, sesuaikan dengan IP laptop server
  // Alternatif untuk development lokal
  // BASE_URL: 'http://localhost:8080'
};

export default API_CONFIG;